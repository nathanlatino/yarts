<?xml version="1.0" encoding="UTF-8"?>
<tileset name="roguelikeSheet_transparent" tilewidth="16" tileheight="16" spacing="1" margin="1" tilecount="1680" columns="56">
 <image source="roguelikeSheet_transparent.png" width="968" height="526"/>
</tileset>
